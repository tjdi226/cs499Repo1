#pragma once
void printTokenIds();
void printProduction(int n);
void printGrammar();
